const CONFIG = {
    BASE_URL: 'https://apikatastrofa.pramuka1133.cloud/',
    DEFAULT_LANGUAGE: 'en-us',
    CACHE_NAME: new Date().toISOString(),
    BASE_WEATHER: 'https://api.weatherapi.com/v1/current.json?key=a97003e04a4644baa5313346240306&q=Jakarta&aqi=yes',
};

export default CONFIG;